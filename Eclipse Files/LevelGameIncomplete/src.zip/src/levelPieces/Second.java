/**
 * @author : Heidi Hufford and Evan Lim
 */

package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class Second extends GamePiece {

	public Second(char symbol, int location) {
		super(symbol, location);
		// TODO Auto-generated constructor stub
	}

	@Override
	public InteractionResult interact(Drawable[] pieces, int playerLocation) {
		
		if (playerLocation == getLocation()) {
			return InteractionResult.GET_POINT;
		}
		// TODO Auto-generated method stub
		return null;
	}

}
