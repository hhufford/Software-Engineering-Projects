/**
 * @author : Heidi Hufford and Evan Lim
 */

package levelPieces;

import gameEngine.Drawable;
import gameEngine.GameEngine;
import gameEngine.InteractionResult;
import gameEngine.Moveable;

public class Fourth extends GamePiece implements Moveable {

	public Fourth(char symbol, int location) {
		super(symbol, location);
		// TODO Auto-generated constructor stub
	}


	@Override
	public InteractionResult interact(Drawable[] pieces, int playerLocation) {
		// TODO Auto-generated method stub
		
	if( playerLocation == getLocation())
	{
		return InteractionResult.KILL;
	}
		return null;
	}


	@Override
	public void move(Drawable[] gameBoard, int playerLocation) {
		// TODO Auto-generated method stub
		if (getLocation() < GameEngine.BOARD_SIZE -1) {
			setLocation(getLocation()+1);
		}
		else {
			setLocation(0);
		}
		
	}
	

		

}
