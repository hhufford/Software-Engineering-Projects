package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class Third extends GamePiece {

	public Third(char symbol, int location) {
		super(symbol, location);
		// TODO Auto-generated constructor stub
	}

	@Override
	public InteractionResult interact(Drawable[] pieces, int playerLocation) {
	
		// TODO Auto-generated method stub
		
		if (playerLocation == getLocation()) {
			return InteractionResult.ADVANCE;
		}
		
		return null;
	}

}
