/**
 * @author : Heidi Hufford and Evan Lim
 */

package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;
import gameEngine.GameEngine;
import java.util.Random;


public class Fith extends GamePiece implements Moveable{

	
	public Fith(char symbol, int location) {
		super(symbol, location);
		// TODO Auto-generated constructor stub
	}

	@Override
	public InteractionResult interact(Drawable[] pieces, int playerLocation) {
		// TODO Auto-generated method stub
		
		if (playerLocation == GameEngine.BOARD_SIZE-2 && getLocation() ==0 )
		{
			return InteractionResult.HIT;
		}
		else if (playerLocation == GameEngine.BOARD_SIZE -1 && getLocation() == 1)
		 {
			 return InteractionResult.HIT; 
		 }
		else if(playerLocation + 2 == getLocation())
		{
			return InteractionResult.HIT;
		}
	return null;
	}

	@Override
	public void move(Drawable[] gameBoard, int playerLocation) {
		// TODO Auto-generated method stub
		Random randVar = new Random();
		
		int num = randVar.nextInt(GameEngine.BOARD_SIZE-1) + 0;
		
		setLocation(num);
		
	}
	

}
