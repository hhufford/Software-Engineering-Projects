package levelPieces;

import java.util.ArrayList;

import gameEngine.Drawable;
import gameEngine.Moveable;

public class LevelEngine {
	
	private int levelNum;
	Drawable[] board;
	private ArrayList<Moveable> movingPieces;
	private ArrayList<GamePiece> interactingPieces;
	private int pStart;
	//-----------------------------------------------------
	
	public LevelEngine() {
		super();
		// TODO Auto-generated constructor stub
	}


	private void levelOne()
	{
		DrawablePiece a = new DrawablePiece('a', 0);
		Second b = new Second('b', 1);
		Third c = new Third('c', 2);
		Fourth d = new Fourth('d', 3);
		Fith e = new Fith('e',4);
			
		
		//board =  
		//movingPieces=;
		//interactingPieces=;
		//pStart=;
	}
	
	public void createLevel(int levelNum) {
		this.levelNum = levelNum;
	}


	public Drawable[] getBoard()
		{
				return board;
		}
	public ArrayList<Moveable> getMovingPieces()
	{
		return movingPieces;
	}
	public ArrayList<GamePiece> getInteractingPieces()
	{
		return interactingPieces;
	}
	
	public int getPlayerStartLoc()
	{
		return pStart;
	}
}
